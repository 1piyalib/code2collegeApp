import * as React from 'react';
import {
  Text,
  View,
  Pressable,
  StyleSheet,
  TextInput,
  ScrollView,
  SafeAreaView,
  Image,
  TouchableOpacity,
} from 'react-native';
import { addFAQ } from '../api/FaqsApi';
import * as firebase from 'firebase';
import 'firebase/auth';
import 'firebase/firestore';
import thinking from '../assets/thinking.jpg';

export default class Posts extends React.Component {
  state = {
    currentFAQname: null,
    currentFAQquest: null,
  };

  checkEmpty = ({navigation}) => {
    if (this.state.currentFAQname === null)
      return alert('Enter a title');
    else if (this.state.currentFAQquest === null)
      return alert('Enter a Comment');
    else if(this.state.currentFAQname!=null)
      return alert('Posted!');
    else
      addFAQ({ 
        name: this.state.currentFAQname,
        question: this.state.currentFAQquest,
      }),
        this.qustInput.clear(),
        this.nameInput.clear(), 
        this.setState((prevState) => ({
          currentFAQname: (prevState.currentFAQname = null), // resets the value of our input to null so another input can be made
        })), // reset value to null
        this.setState((prevState) => ({
          currentFAQquest: (prevState.currentFAQquest = null), // resets the value of our input to null so another input can be made
        })), // reset value to null
        alert('Your post has been sent') // Let the user know that there post was successfully sent
  };

  render() {
    return (
      <ScrollView
        style={{ height: '100%', width: '100%' }}
        keyboardShouldPersistTaps="handled">
        <View style={styles.page}>
          <View style={styles.postField}>
            <TextInput
              style={styles.inputField}
              ref={(input) => {
                this.nameInput = input;
              }}
              placeholder="What's the topic of your post?"
              multiline={true}
              value={this.state.currentFAQname}
              onChangeText={(title) =>
                this.setState((prevState) => ({
                  currentFAQname: (prevState.currentFAQname = title),
                }))
              }
            />
            <TextInput
              style={ styles.inputField }
              ref={(input) => {
                this.qustInput = input;
              }}
              placeholder="What's on your mind?"
              multiline={true}
              value={this.state.currentFAQquest}
              onChangeText={(quest) =>
                this.setState((prevState) => ({
                  currentFAQquest: (prevState.currentFAQquest = quest),
                }))
              }
            />
          </View>


          <View>
          <Image style={styles.logo} source={thinking}></Image>
        </View>

          <View style={{ backgroundColor: '#7BF496' }}>
            <Pressable title="Submit" onPress={() => this.checkEmpty()}>
              <Text>Click here to post!</Text>
            </Pressable>
          </View>


          <View
          style={{
            flex: 0.5,
            backgroundColor: 'lightblue',
            justifyContent: 'center',
            height: 100, 
            marginTop: 10
          }}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => navigation.navigate('Home')}><Text>Back</Text></TouchableOpacity>
        </View>

        </View>
      </ScrollView>
    );
  }
}

const styles = StyleSheet.create({
  inputField: {
    border: 'solid',
    borderColor: 'lightblue',
    margin: '1%',
  },
  logo: {
    height: 200,
    width: 350,
    opacity: 0.5,

    marginRight: 100,
  },
  backButton: {
    padding: 10,
    color: 'white',
  },
});