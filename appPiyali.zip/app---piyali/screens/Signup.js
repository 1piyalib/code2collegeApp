import * as React from 'react';
import sloth from '../assets/sloth.jpg';
import {
  Text,
  View,
  Pressable,
  StyleSheet,
  Image,
  Button,
  TextInput,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import firebase from "firebase/app"
import "firebase/auth"
import "firebase/firestore"

const Signup = ({ navigation }) => {
  const [firstName, setFirstName] = React.useState('');
  const [lastName, setLastName] = React.useState('');
  const [email, setEmail] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [confirmPassword, setConfirmPassword] = React.useState('');
  const onSignupPress = () => {
    if (password != confirmPassword) {
      alert("Passwords don't match!");
      return;
    }
    firebase
      .auth()
      .createUserWithEmailAndPassword(email, password)
      .then((response) => {
        const uid = response.user.uid;
        const data = {
          id: uid,
          email,
          firstName,
          lastName,
        };
        const usersRef = firebase.firestore().collection('users');
        usersRef
          .doc(uid)
          .set(data)
          .then(() => {
            alert('Account Created!');
            navigation.navigate('Home');
          })
          .catch((error) => {
            alert(error);
          });
      })
      .catch((error) => {
        alert(error);
      });
  };

  return (
    <View style={{ flex: 1 }}>
      <View style={{ flex: 0.7, backgroundColor: 'pink' }}>
        <View style={{ flexDirection: 'row', justifyContent: 'left' }}>
          <Text style={styles.pageTitle}>Sign up here! :)</Text>
        </View>
      </View>
      <View style={{ flex: 5, backgroundColor: 'pink' }}>
        <View>
          <Text style={styles.homeText}>Enter your information below to join</Text>
        </View>
        <View
          style={{
            justifyContent: 'center',
            marginLeft: 50,
            marginRight: 50,
          }}>
          <TextInput
            style={styles.input}
            placeholder="First Name"
            value={firstName}
            onChangeText={(firstName) => setFirstName(firstName)}
          />
          <TextInput
            style={styles.input}
            placeholder="Last Name"
            value={lastName}
            onChangeText={(lastName) => setLastName(lastName)}
          />
          <TextInput
            style={styles.input}
            placeholder="Email"
            value={email}
            onChangeText={(email) => setEmail(email)}
          />
          <TextInput
            style={styles.input}
            placeholder="Password"
            onChangeText={(password) => setPassword(password)}
            value={password}
            secureTextEntry={true}
          />
          <TextInput
            style={styles.input}
            placeholder="Confirm Password"
            onChangeText={(confirmPassword) =>
              setConfirmPassword(confirmPassword)
              
            }
            value={confirmPassword}
            secureTextEntry={true}
          />
        </View>
        <View>
          <View style={styles.homeText}>
            <Button title="Sign Up" onPress={() => onSignupPress()}></Button>
          </View>
          <View style={styles.fixToText}></View>
        </View>
        <View>
          <Image style={styles.logo} source={sloth} />
        </View>
        <View
          style={{
            flex: 0.2,
            backgroundColor: 'lightblue',
            justifyContent: 'center',
          }}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => navigation.navigate('Login')}><Text>Back</Text></TouchableOpacity>
        </View>
      </View>
    </View>
  );
};
export default Signup;

const styles = StyleSheet.create({
  pageTitle: {
    margin: 10,
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    opacity: 0.5,
  },
  fixToText: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginHorizontal: 55,
    padding: 8,
  },
  input: {
    height: 40,
    borderColor: 'black',
    borderWidth: 1.4,
    width: 280,
    backgroundColor: 'lightgrey',
    textAlign: 'left',
    paddingLeft: 12,
    marginBottom: 20,
    alignSelf: 'center',
  },
  logo: {
    height: 100,
    width: 100,

    marginLeft: 110,
    marginRight: 100,
  },
  homeText: {
    margin: 10,
    marginBottom: 20,
    fontSize: 16,
    textAlign: 'center',
    color: 'black',
  },
  backButton: {
    padding: 10,
    color: 'white',
  },
});
