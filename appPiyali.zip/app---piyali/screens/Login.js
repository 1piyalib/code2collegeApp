import * as React from 'react';
import sheep from '../assets/sheep.png';
import {
  Text,
  View,
  Pressable,
  StyleSheet,
  Image,
  Button,
  TextInput,
  ScrollView,
}from 'react-native';
import firebase from "firebase/app"
import "firebase/auth"
import "firebase/firestore"

const Login = ({navigation}) => {
  const [username, onChangeUsername] = React.useState('')
  const [password, onChangePassword] = React.useState('')

  const onLoginPress = () => {
    firebase.auth().signInWithEmailAndPassword(username, password).then((response) => {
        const uid = response.user.uid;
        const usersRef = firebase.firestore().collection('users');
        alert('Logged In');
        navigation.navigate('Home');
      })
      .catch((error) => {
        alert(error);
      });
  };

  return (
    <View style={{ flex: 1 }}>
      <View style={{ flex: 0.7, backgroundColor: 'pink' }}>
        <View style={{ flexDirection: 'row', justifyContent: 'center' }}>
          <Text style={styles.pageTitle}>Animals App</Text>
        </View>
      </View>
      <View style={{ flex: 5, backgroundColor: 'lightblue' }}>
        <View>
          <Text style={styles.homeText}>
            One step closer to seeing your favorite animals!
          </Text>
        </View>
        <View
          style={{
            justifyContent: 'center',
            marginLeft: 50,
            marginRight: 50,
          }}>
            <TextInput
            style={styles.input}
            placeholder="Your Username"
            value={username}
            onChangeText={(username) => onChangeUsername(username)}/>
            <TextInput
            style={styles.input}
            placeholder="Your Password"
            onChangeText={(password) => onChangePassword(password)}
            value={password}/>
        </View>
        <View>
          <View style={styles.homeText}>
            <Button
              title="Login"
              onPress={() => navigation.navigate('Home')}></Button>
          </View>
          <View style={styles.fixToText}>
            <Text> Don't have an account? </Text>
          </View>
          <View style={styles.homeText}>
            <Button
              title="Sign Up"
              onPress={() => navigation.navigate('Signup')}></Button>
          </View>
        </View>
        <View>
          <Image style={styles.logo} source={sheep}></Image>
        </View>

      <View style={styles.fixToText}>
            <Button
              title="Home"
              onPress={() => navigation.navigate('Home')}></Button>
          </View>



      </View>

      <View style={{ flex: 0.5, backgroundColor: 'pink' }}></View>
    </View>
  );
};
export default Login;

const styles = StyleSheet.create({
  pageTitle: {
    margin: 10,
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    opacity: 0.5,
  },
  fixToText: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginHorizontal: 55,
    padding: 8,
  },
  input: {
    height: 40,
    borderColor: 'black',
    borderWidth: 1.4,
    width: 160,
    backgroundColor: 'white',
    textAlign: 'center',
    marginTop: 20,
    alignSelf: 'center',
  },
  logo: {
    height: 100,
    width: 100,

    marginLeft: 120,
    marginRight: 100,
  },
  homeText: {
    margin: 10,
    fontSize: 16,
    textAlign: 'center',
    color: 'grey',
  }
});
