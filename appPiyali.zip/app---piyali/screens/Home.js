import * as React from 'react';
import {
  Text,
  View,
  ScrollView,
  Pressable,
  StyleSheet,
  Image,
  Linking,
  Alert,
  Button,
  TouchableOpacity,
  Video,
} from 'react-native';



const redditpage =
  'https://www.reddit.com/r/Animals/';
const donate =
  'https://www.austintexas.gov/department/support-animal-center';
const exoticAnimals =
  'https://a-z-animals.com/pets/exotic-pets/';

const ExternalLink = (props) => {
  const { url, children, style = {} } = props;

  const onPress = () =>
    Linking.canOpenURL(url).then(() => {
      Linking.openURL(url);
    });
    return(
      <TouchableOpacity onPress={onPress}>
        <Text style={[styles.linkButton, style]}>{children}</Text>
      </TouchableOpacity>
    )
};

const Home = ({navigation}) => {
  return (
    <ScrollView
      style={{ height: '100%', backgroundColor: '#f27778', paddingTop: 30 }}>
      <Text style={styles.pageTitle}>You're here!</Text>
      <View style={styles.linkContainer}>
        <Text style={styles.pageIntro}>
          Welcome to your favorite animal app and prepare to see the cutest animals ever.
        </Text>
        
        




      </View>
      
      <View style={styles.spacingContainer}>
      <Pressable onPress={() => navigation.navigate('Comments')}>
        <View style={styles.pageLinesAlignment}>
          <Text style={styles.pageLinesTextStyle}>
            Questions?
          </Text>
        </View>
      </Pressable>
        <View style={styles.iconContainer}>
          <Image
            style={styles.tinyLogo}
            source={{
              uri: 'https://i.pinimg.com/736x/5e/cc/35/5ecc3503fc405cc7593e041269d9fcc8.jpg',
            }}
          />
        </View>
      </View>

      

      <Text style={styles.pageIntro}>
        {' '}
        You might ask, what is this app's purpose? We here at AnimalApp Inc believe that animals give you all the serotonin you need, ever. Enjoy the rush!
        {' '}
      </Text>

      <View style={styles.spacingContainer}>
       <Pressable onPress={() => navigation.navigate('Account')}>
        <View style={styles.pageLinesAlignment}>
          <Text style={styles.pageLinesTextStyle}> Account Page </Text>
        </View>
      </Pressable>
        <View style={styles.iconContainer}>
          <Image
            style={styles.tinyLogo}
            source={{
              uri: 'https://media.istockphoto.com/photos/funny-raccoon-in-green-sunglasses-showing-a-rock-gesture-isolated-on-picture-id1154370446?k=20&m=1154370446&s=612x612&w=0&h=2AWvof66ovB87P3b7C_cu0pCZlZhDDFYUFr2KQ2UnwQ=',
            }}
          />
        </View>
      </View>

     

      <Text style={styles.pageIntro}>
        {' '}
        Wanna see your profile? Click here!
      </Text>


      <ExternalLink url={redditpage}>Want to see more animals?</ExternalLink>
      <ExternalLink url={donate}>Want to donate?</ExternalLink>
      <ExternalLink url={exoticAnimals}>Are you a fan of exotic animals?</ExternalLink>

    
      <View style={styles.logo}>
       <View>
       <TouchableOpacity onPress={() =>Linking.openURL("https://www.smithsonianmag.com/smithsonian-institution/sad-story-laika-space-dog-and-her-one-way-trip-orbit-1-180968728/")}>
        <Image style={{height:50,width:50}} source={{uri:"https://cdn.britannica.com/86/104286-050-87BACED6/Laika-creature-space-Sputnik-2-November-1957.jpg"}} />
        </TouchableOpacity>
       </View>
       <View>
        <TouchableOpacity onPress={() =>Linking.openURL("https://www.whalefacts.org/what-do-whales-do/")}>
        <Image style={{height:50,width:50}} source={{uri:"https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/majestic-whale-photos-1531339408.jpg?crop=1.00xw:0.935xh;0,0.0565xh&resize=1200:*"}} />
        </TouchableOpacity>
       </View>
      </View>

    </ScrollView>
  );
};
export default Home;

const styles = StyleSheet.create({
  spacingContainer: {
    paddingTop: 40,
  },
  pageTitle: {
    margin: 10,
    fontSize: 26,
    fontFamily: 'Arial',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  pageLinesAlignment: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  pageLinesTextStyle: {
    margin: 5,
    fontSize:20,
    fontFamily: 'Cambria',


    elevation: 3,
    zIndex: 999,
  },
  pageIntro: {
    margin: 3,
    fontSize: 16,
    fontFamily: 'Times New Roman',
    textAlign: 'center',
    paddingLeft: 15,
    paddingRight: 15,
  },
  tinyLogo: {
    height: 80,
    width: 80,
    textAlign: 'center',
    borderRadius: 400 / 2,
  },
  iconContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  linkContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  linkButton: {
    backgroundColor: '#4A2511',
    padding: 10,
    margin: 5,
    height: 40,
    color: 'white',
  },
  logo: {
    height: 100,
    width: 100,
    marginLeft: 110,
    marginRight: 100,
  },
});
