
import * as React from 'react';
import { Text, View, StyleSheet, Dimensions, Platform } from 'react-native';

import Home from './screens/Home';
import Account from './screens/Account';
import Login from './screens/Login';
import Posts from './screens/Posts';
import Signup from './screens/Signup';
import Comments from './screens/Comments';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

// // Import firebase JS SDK
// import * as firebase from 'firebase';
// import "firebase/auth";
// import "firebase/firestore";

// // Your web app's Firebase configuration
// if (!firebase.apps.length) {
//   const firebaseConfig = {
//   apiKey: "AIzaSyDoNORPuxldO642XDWF9ZGCJCSjDViXQ8k",
//   authDomain: "mobiledevbootcamp.firebaseapp.com",
//   projectId: "mobiledevbootcamp",
//   storageBucket: "mobiledevbootcamp.appspot.com",
//   messagingSenderId: "979002329444",
//   appId: "1:979002329444:web:772d548b846ed51b069271"
//   };
//   // Initialize Firebase
//   firebase.initializeApp(firebaseConfig);
// }
 
const webPreviewWidth = 300;
const webPreviewHeight = 550;
const screenWidth =
  Platform.OS === 'web' ? webPreviewWidth : Dimensions.get('screen').width;
const screenHeight =
  Platform.OS === 'web'
    ? webPreviewHeight
    : Dimensions.get('screen').height - Constants.statusBarHeight;

const Stack = createStackNavigator();
function App() {
  return (
    <NavigationContainer screenOptions={{ headerMode: 'none' }}>
      <Stack.Navigator
        initialRouteName="Login" //change where you want to go here
        screenOptions={{ animationEnabled: false, headerShown: false }}>
        <Stack.Screen name="Home" component={Home} />
        <Stack.Screen name="Comments" component={Comments} />
        <Stack.Screen name="Account" component={Account} />
        <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="Signup" component={Signup} />
        <Stack.Screen name="Posts" component={Posts} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
export default App;